# GITMOD1
This is a github demo.

# Instructions on the project
- Creation of file1.txt @m0sesa
- Creation of file11.txt @m0sesa
- Creation of file2.txt @stephencvg
- Creation of file22.txt @stephencvg
- Creation of file3.txt @graciouSmkx
- Creation of file33.txt @graciouSmkx